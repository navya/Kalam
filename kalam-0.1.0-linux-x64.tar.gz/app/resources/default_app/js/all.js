
    function toggleabout() {
        el = document.getElementById("about");
        el.style.visibility = (el.style.visibility == "visible") ? "hidden" : "visible";
    }
